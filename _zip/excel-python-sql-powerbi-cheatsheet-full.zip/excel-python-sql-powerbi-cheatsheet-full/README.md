# Excel → Python → SQL → Power BI Cheat Sheet

Repositório oficial: https://github.com/vagnerx/excel-python-sql-powerbi-cheatsheet

Veja a pasta docs.