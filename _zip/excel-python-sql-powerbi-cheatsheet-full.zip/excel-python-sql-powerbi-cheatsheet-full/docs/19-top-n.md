# 19. Top N

## Explicação Conceitual
Descrição conceitual da operação.

## Dataset utilizado
`datasets/sales.csv`

## Excel
**Como fazer:** Excel

## Python
```python
Python
```

## SQL
```sql
SQL
```

## Power BI
**Implementação:** Power BI

> **M**: ETL e transformação.
> **DAX**: medidas e cálculos analíticos.

## Quando usar
- Uso prático.

## Armadilhas comuns
- Armadilhas comuns.

## Referências cruzadas
- Veja também: Merge/Join, Filtrar Linhas, Agrupar Dados.
