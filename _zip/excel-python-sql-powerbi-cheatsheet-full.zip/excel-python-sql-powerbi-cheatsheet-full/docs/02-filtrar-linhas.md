# 02. Filtrar Linhas

## Explicação Conceitual
Selecionar subconjuntos de registros.

## Dataset utilizado
`datasets/sales.csv`

## Excel
**Como fazer:** Dados > Filtro

## Python
```python
df[df['valor']>100]
```

## SQL
```sql
WHERE valor>100
```

## Power BI
**Implementação:** CALCULATE(...)(DAX)

> **M**: ETL e transformação.
> **DAX**: medidas e cálculos analíticos.

## Quando usar
- Aplicar regras de negócio.

## Armadilhas comuns
- Filtros conflitantes.

## Referências cruzadas
- Veja também: Merge/Join, Filtrar Linhas, Agrupar Dados.
