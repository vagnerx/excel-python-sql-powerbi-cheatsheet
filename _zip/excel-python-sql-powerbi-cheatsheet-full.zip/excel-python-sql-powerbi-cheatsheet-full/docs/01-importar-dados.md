# 01. Importar Dados

## Explicação Conceitual
Trazer dados de arquivos, APIs ou bancos para análise.

## Dataset utilizado
`datasets/sales.csv`

## Excel
**Como fazer:** Abrir arquivo ou Power Query

## Python
```python
pd.read_csv('sales.csv')
```

## SQL
```sql
SELECT * FROM vendas;
```

## Power BI
**Implementação:** Obter Dados (M)

> **M**: ETL e transformação.
> **DAX**: medidas e cálculos analíticos.

## Quando usar
- Início de qualquer análise.

## Armadilhas comuns
- Confundir leitura com persistência.

## Referências cruzadas
- Veja também: Merge/Join, Filtrar Linhas, Agrupar Dados.
