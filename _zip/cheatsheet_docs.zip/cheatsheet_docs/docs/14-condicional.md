# Coluna Condicional

## Explicação Conceitual
Descrição da operação.

## Excel
Exemplo.

## Python
```python
# exemplo
```

## SQL
```sql
-- exemplo
```

## Power BI
Exemplo indicando (M) ou (DAX).

## Quando usar
Casos de uso.

## Armadilhas comuns
- Erros frequentes.
