# Exemplos DAX e M

DAX: SUM(), CALCULATE(), RANKX()
M: Merge, Unpivot, Change Type